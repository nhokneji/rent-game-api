create procedure ProcGetListGameAccountByShopId(IN shopId INTEGER(10))
  BEGIN
	select b.name,a.* from tbl_game_account a inner join tbl_game b on  a.game_id=b.id where a.shop_id=shopId;
END;

