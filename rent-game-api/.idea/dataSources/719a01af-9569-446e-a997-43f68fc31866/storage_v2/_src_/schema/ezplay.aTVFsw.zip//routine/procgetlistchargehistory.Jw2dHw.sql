create procedure ProcGetListChargeHistory(IN offsets INT(10), IN limits INT(10), IN user_id INT(10),
                                          IN sort    NVARCHAR(50))
  BEGIN
	SET @limit_sp = CONCAT(' LIMIT ', offsets , ',', limits);
    SET @query = CONCAT( "SELECT a.id,a.transaction_time,a.value, a.explains,a.serial,a.user_id,b.display_name FROM ezplay.tbl_charge_history a inner join tbl_user b on a.user_id=b.user_id where a.user_id= ",user_id," order by a.transaction_time ",sort);
    SET @query = CONCAT(@query, @limit_sp);
    PREPARE stmt FROM @query;
    EXECUTE stmt ;
    DEALLOCATE PREPARE stmt ;
END;

