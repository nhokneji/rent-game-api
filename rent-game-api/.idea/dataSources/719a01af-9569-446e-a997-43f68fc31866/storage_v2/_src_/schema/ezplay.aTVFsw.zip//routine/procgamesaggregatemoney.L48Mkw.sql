create procedure ProcGamesAggregateMoney(IN shop_id INTEGER(10), IN agg_status INTEGER(10))
  BEGIN
	SELECT a.game,a.game_id,sum(amount) as total_amount,sum(duration) as total_duration FROM tbl_rent_history a where shop_id=shop_id and status =agg_status group by a.game_id;
END;

