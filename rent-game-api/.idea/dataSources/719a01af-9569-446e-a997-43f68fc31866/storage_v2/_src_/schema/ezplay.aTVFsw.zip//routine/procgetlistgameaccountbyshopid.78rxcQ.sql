create procedure ProcGetListGameAccountByShopId(IN shopId INT(10), IN offsets INT(10), IN limits INT(10))
  BEGIN
	SET @limit_sp = CONCAT(' LIMIT ', offsets , ',', limits);
    SET @query = CONCAT( "select b.name,a.* from tbl_game_account a inner join tbl_game b on  a.game_id=b.id where a.shop_id=",shopId);
    SET @query = CONCAT(@query, @limit_sp);
    PREPARE stmt FROM @query;
    EXECUTE stmt ;
    DEALLOCATE PREPARE stmt ;
END;

