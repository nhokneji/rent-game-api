create procedure ProcRentHistoryByShop(IN shopId INT(10), IN offsets INT(10), IN limits INT(10))
  BEGIN
	SET @limit_sp = CONCAT(' LIMIT ', offsets , ',', limits);
    SET @query = CONCAT( "select a.*,b.account from tbl_rent_history a inner join tbl_game_account b on a.account_id=b.id where a.shop_id =",shopId);
    SET @query = CONCAT(@query, @limit_sp);
    PREPARE stmt FROM @query;
    EXECUTE stmt ;
    DEALLOCATE PREPARE stmt ;
END;

